/**
 * AnimatedBeamGrid — Live animated grid with glowing beams
 * Inspired by shadcn/ui, Aceternity, and 21st.dev designs
 */
import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface BeamProps {
  top?: string | number;
  left?: string | number;
  rotate?: number;
  delay?: number;
  duration?: number;
  width?: number;
  opacity?: number;
  color?: string;
}

const Beam = ({ top = "10%", left = "50%", rotate = 0, delay = 0, duration = 8, width = 1, opacity = 0.15, color = "#00c3eb" }: BeamProps) => (
  <motion.div
    className="absolute pointer-events-none"
    style={{
      top,
      left,
      width: `${width}px`,
      height: "100vh",
      background: `linear-gradient(to bottom, transparent, ${color}, transparent)`,
      rotate: `${rotate}deg`,
      transformOrigin: "top center",
      opacity: 0,
    }}
    animate={{
      opacity: [0, opacity, 0],
      scaleY: [0.3, 1.2, 0.3],
    }}
    transition={{
      duration,
      repeat: Infinity,
      delay,
      ease: "easeInOut",
    }}
  />
);

interface GridFlashProps {
  row: number;
  col: number;
  color: string;
  delay: number;
}

const GridFlash = ({ row, col, color, delay }: GridFlashProps) => (
  <motion.div
    className="absolute pointer-events-none rounded-sm"
    style={{
      top: `${row * 60}px`,
      left: `${col * 60}px`,
      width: "60px",
      height: "60px",
    }}
    animate={{
      backgroundColor: [`${color}00`, `${color}18`, `${color}00`],
    }}
    transition={{
      duration: 3,
      repeat: Infinity,
      delay,
      ease: "easeInOut",
    }}
  />
);

export const AnimatedBeamGrid = ({ className = "", dark = true }: { className?: string; dark?: boolean }) => {
  const [flashes, setFlashes] = useState<GridFlashProps[]>([]);

  useEffect(() => {
    // Random grid flashes
    const arr: GridFlashProps[] = [];
    for (let i = 0; i < 15; i++) {
      arr.push({
        row: Math.floor(Math.random() * 20),
        col: Math.floor(Math.random() * 30),
        color: Math.random() > 0.5 ? "#00c3eb" : "#6366f1",
        delay: Math.random() * 5,
      });
    }
    setFlashes(arr);
  }, []);

  const beamColor = dark ? "#00c3eb" : "#0891b2";
  const gridColor = dark ? "rgba(0,162,199,0.07)" : "rgba(0,130,160,0.05)";

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      {/* Grid pattern */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `linear-gradient(${gridColor} 1px, transparent 1px), linear-gradient(90deg, ${gridColor} 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Random cell flashes */}
      {flashes.map((f, i) => (
        <GridFlash key={i} {...f} />
      ))}

      {/* Animated beams */}
      <Beam top="0%" left="15%" rotate={15} delay={0} duration={10} color={beamColor} opacity={0.12} />
      <Beam top="0%" left="35%" rotate={0} delay={2} duration={8} color="#6366f1" opacity={0.1} />
      <Beam top="0%" left="65%" rotate={-8} delay={4} duration={12} color={beamColor} opacity={0.12} />
      <Beam top="0%" left="85%" rotate={5} delay={1} duration={9} color="#a855f7" opacity={0.08} />

      {/* Corner glow spots */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[200px] bg-blue-500/3 rounded-full blur-3xl" />
    </div>
  );
};
