import { motion } from "framer-motion";
import { Monitor, Smartphone, Globe, Shield } from "lucide-react";
import { TiltCard } from "./TiltCard";
import { AnimatedBeamGrid } from "./AnimatedBeamGrid";

/**
 * EcosystemLayers3D — Awwwards-style isometric floating planes
 * showing the 3-layer CopMap architecture with depth + perspective.
 */

const layers = [
  {
    label: "01 — Command Dashboard",
    sublabel: "Web Portal",
    desc: "Full-force oversight. Every zone, every officer, live.",
    Icon: Monitor,
    color: "#00c3eb",
    z: 90,
    chips: ["250+ Deploy Points", "Real-Time Sync", "Role-Based Access"],
  },
  {
    label: "02 — Mobile Officer App",
    sublabel: "Field Device",
    desc: "GPS check-in, duty log, patrol tracking — in every pocket.",
    Icon: Smartphone,
    color: "#38bdf8",
    z: 0,
    chips: ["GPS Tracking", "Offline Mode", "Encrypted Push"],
  },
  {
    label: "03 — Data & GPS Network",
    sublabel: "Infrastructure",
    desc: "AES-256 encrypted backbone with 99.9% uptime SLA.",
    Icon: Globe,
    color: "#a78bfa",
    z: -90,
    chips: ["AES-256", "IN-Region Data", "WebSocket Stream"],
  },
];

export const EcosystemLayers3D = () => {
  return (
    <section className="py-24 relative overflow-hidden border-t border-white/5"
      style={{ background: "linear-gradient(180deg, #030f1e 0%, #040d1a 100%)" }}>
      {/* Animated grid background */}
      <AnimatedBeamGrid dark={true} />
      
      {/* Ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-[#00a2c7]/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="container mx-auto px-4 lg:px-8 max-w-[1360px] relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.div initial={{ opacity:0, y:12 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}
            className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.24em] text-[#00a2c7] mb-5 bg-[#00a2c7]/10 px-4 py-2 rounded-full border border-[#00a2c7]/20">
            <Shield size={10} />
            Platform Architecture
          </motion.div>
          <motion.h2 initial={{ opacity:0, y:16 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }} transition={{ delay:0.1 }}
            className="text-4xl lg:text-5xl font-heading font-black text-white tracking-tighter leading-[1.05] mb-4">
            Three layers.{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00c3eb] to-sky-400">
              One system.
            </span>
          </motion.h2>
          <motion.p initial={{ opacity:0 }} whileInView={{ opacity:1 }} viewport={{ once:true }} transition={{ delay:0.2 }}
            className="text-slate-400 text-lg max-w-lg mx-auto leading-relaxed">
            From the Commissioner's screen to the constable's pocket — every layer talks in real time.
          </motion.p>
        </div>

        {/* 3D Layer stack — perspective container */}
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">

          {/* LEFT — 3D isometric planes */}
          <motion.div
            initial={{ opacity:0, x:-30 }} whileInView={{ opacity:1, x:0 }} viewport={{ once:true }} transition={{ duration:0.8, ease:[0.22,1,0.36,1] }}
            className="relative w-full lg:w-[520px] flex-shrink-0"
            style={{ perspective: "1000px", height: 360 }}
          >
            <div style={{ transformStyle:"preserve-3d", position:"relative", height:"100%" }}>
              {layers.map((layer, i) => (
                <motion.div
                  key={layer.label}
                  initial={{ opacity:0, z:-60 }}
                  whileInView={{ opacity:1, z:0 }}
                  viewport={{ once:true }}
                  transition={{ delay: 0.15 + i * 0.18, duration:0.9, ease:[0.22,1,0.36,1] }}
                  className="absolute w-full animate-float"
                  style={{
                    top: `${i * 108}px`,
                    animationDelay: `${i * 0.9}s`,
                    transform: `perspective(1000px) rotateX(28deg) rotateY(-8deg) translateZ(${layer.z * 0.35}px)`,
                    transformStyle: "preserve-3d",
                  }}
                >
                  {/* Layer plane */}
                  <div
                    className="relative rounded-2xl overflow-hidden"
                    style={{
                      background: `linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.02) 100%)`,
                      border: `1px solid ${layer.color}25`,
                      borderTop: `1px solid ${layer.color}45`,
                      boxShadow: `0 20px 40px rgba(0,0,0,0.4), 0 0 0 1px ${layer.color}10, inset 0 1px 0 rgba(255,255,255,0.07)`,
                      backdropFilter: "blur(16px)",
                    }}
                  >
                    {/* Shimmer sweep */}
                    <div className="absolute inset-0 shimmer-surface pointer-events-none" />
                    {/* Top accent line */}
                    <div className="absolute top-0 left-8 right-8 h-px" style={{ background: `linear-gradient(90deg, transparent, ${layer.color}60, transparent)` }} />

                    <div className="flex items-center gap-5 px-6 py-4">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor:`${layer.color}15`, border:`1px solid ${layer.color}30` }}>
                        <layer.Icon size={18} style={{ color: layer.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-[8px] font-black uppercase tracking-[0.22em] mb-0.5" style={{ color: `${layer.color}80` }}>{layer.sublabel}</div>
                        <div className="text-[12px] font-black text-white leading-tight truncate">{layer.label}</div>
                      </div>
                      {/* Connection dots */}
                      <div className="flex gap-1 flex-shrink-0">
                        {[0,1,2].map(d=>(
                          <motion.div key={d} className="w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: layer.color }}
                            animate={{ opacity:[0.3,1,0.3], scale:[0.8,1.2,0.8] }}
                            transition={{ duration:1.5, delay:d*0.3, repeat:Infinity }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Connecting vertical line to next layer */}
                  {i < layers.length - 1 && (
                    <div className="absolute left-[3rem] -bottom-6 w-px h-6"
                      style={{ background: `linear-gradient(to bottom, ${layer.color}50, ${layers[i+1].color}30)` }} />
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* RIGHT — Detail cards */}
          <div className="flex-1 space-y-4">
            {layers.map((layer, i) => (
              <motion.div
                key={layer.label}
                initial={{ opacity:0, x:24 }} whileInView={{ opacity:1, x:0 }} viewport={{ once:true }}
                transition={{ delay:0.2 + i * 0.15, duration:0.6, ease:[0.22,1,0.36,1] }}
              >
                <TiltCard intensity={8} scale={1.03}>
                  <div
                    className="group relative rounded-2xl p-5 cursor-default overflow-hidden transition-all duration-400"
                    style={{
                      background: "rgba(255,255,255,0.02)",
                      border: `1px solid rgba(255,255,255,0.06)`,
                    }}
                  >
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
                      style={{ background: `radial-gradient(ellipse at 20% 50%, ${layer.color}10, transparent 70%)` }} />
                    <div className="absolute top-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                      style={{ background: `linear-gradient(90deg, transparent, ${layer.color}50, transparent)` }} />

                    <div className="relative z-10 flex items-start gap-4">
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                        style={{ backgroundColor:`${layer.color}12`, border:`1px solid ${layer.color}25` }}>
                        <layer.Icon size={15} style={{ color: layer.color }} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[9px] font-black uppercase tracking-[0.2em]" style={{ color:`${layer.color}80` }}>{layer.sublabel}</span>
                        </div>
                        <h3 className="text-sm font-black text-white mb-1.5">{layer.label.replace(/^\d+ — /, "")}</h3>
                        <p className="text-xs text-slate-500 leading-relaxed mb-3">{layer.desc}</p>
                        <div className="flex flex-wrap gap-1.5">
                          {layer.chips.map(c=>(
                            <span key={c} className="text-[7px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full"
                              style={{ backgroundColor:`${layer.color}12`, border:`1px solid ${layer.color}25`, color:layer.color }}>
                              {c}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EcosystemLayers3D;
