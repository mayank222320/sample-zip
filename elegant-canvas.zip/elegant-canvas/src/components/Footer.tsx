import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, Linkedin, Twitter, Facebook, Instagram } from "lucide-react";
import EmailObfuscator from "./seo/EmailObfuscator";

const Footer = () => {
  return (
    <footer className="relative border-t border-slate-200 dark:border-white/5 bg-white dark:bg-[hsl(222,47%,6%)] transition-colors duration-300">
      {/* top accent line */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-px bg-gradient-to-r from-transparent via-blue-500/50 to-transparent" />

      <div className="container mx-auto px-6 lg:px-12 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

          {/* Brand */}
          <div className="lg:col-span-1 flex flex-col">
            <Link to="/" className="flex items-center gap-2.5 mb-5">
              <img src="/Copmap-logo.png" alt="CopMap" className="h-9 w-9 object-contain brightness-0 dark:invert" />
              <span className="text-lg font-heading font-bold text-slate-900 dark:text-white">CopMap</span>
            </Link>
            <p className="text-sm text-slate-500 dark:text-white/45 leading-relaxed">
              India's purpose-built SaaS platform for law enforcement from a single station to an entire state.
            </p>
            
            {/* Social Links */}
            <div className="mt-8 flex gap-3">
              {[
                { icon: Linkedin, href: "#", label: "LinkedIn" },
                { icon: Twitter, href: "#", label: "Twitter" },
                { icon: Facebook, href: "#", label: "Facebook" },
                { icon: Instagram, href: "#", label: "Instagram" },
              ].map((social) => (
                <a 
                  key={social.label} 
                  href={social.href} 
                  aria-label={social.label}
                  className="w-9 h-9 rounded-full bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center justify-center text-slate-500 dark:text-white/45 hover:text-[#00c3eb] hover:border-[#00c3eb]/30 hover:bg-[#00c3eb]/10 transition-all duration-300"
                >
                  <social.icon size={15} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 dark:text-white/25 mb-5">Quick Links</h4>
            <div className="flex flex-col gap-2.5">
              {[
                { label: "Home", to: "/" },
                { label: "Product", to: "/product" },
                { label: "Features", to: "/features" },
                { label: "About Us", to: "/about" },
                { label: "Contact", to: "/contact" },
              ].map((link) => (
                <Link key={link.label} to={link.to} className="text-sm text-slate-500 dark:text-white/45 hover:text-[#00c3eb] transition-colors">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Features */}
          <div>
            <h4 className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 dark:text-white/25 mb-5">Features</h4>
            <div className="flex flex-col gap-2.5">
              {[
                { name: "Bandobast Management", hash: "#bandobast" },
                { name: "Patrolling Operations", hash: "#patrolling" },
                { name: "Resource Requirement", hash: "#resource" },
                { name: "Attendance Management", hash: "#attendance" },
                { name: "Leave Management", hash: "#leave" },
                { name: "Officer Management", hash: "#officers" },
              ].map((f) => (
                <Link key={f.name} to={`/features${f.hash}`} className="text-sm text-slate-500 dark:text-white/45 hover:text-[#00c3eb] transition-colors">
                  {f.name}
                </Link>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 dark:text-white/25 mb-5">Contact</h4>
            <div className="flex flex-col gap-3">
              <EmailObfuscator 
                email="info@copmap.in" 
                className="flex items-center gap-2.5 text-sm text-slate-500 dark:text-white/45 hover:text-[#00c3eb] transition-colors"
                icon={<Mail size={13} className="shrink-0" />}
              />
              <a href="tel:+918855891936" className="flex items-center gap-2.5 text-sm text-slate-500 dark:text-white/45 hover:text-[#00c3eb] transition-colors">
                <Phone size={13} className="shrink-0" />
                +91 8855891936
              </a>
              <div className="flex items-start gap-2.5 text-sm text-slate-500 dark:text-white/45">
                <MapPin size={13} className="mt-0.5 shrink-0" />
                <span>10/81, Near SJP Petrol Pump, Bidkin, Chhatrapati Sambhajinagar – 431105, Maharashtra, India</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-slate-200 dark:border-white/5 mt-14 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-400 dark:text-white/25">
            © {new Date().getFullYear()} CopMap — EyeQlytics Technologies Private Limited. All rights reserved.
          </p>
          <div className="flex gap-6">
            {[
              { label: "Privacy Policy", to: "/privacy" },
              { label: "Terms & Conditions", to: "/terms" },
              { label: "Security Policy", to: "/security" },
              { label: "Vulnerability Disclosure", to: "/security#section-11" },
            ].map((t) => (
              <Link key={t.label} to={t.to} className="text-xs text-slate-400 dark:text-white/25 hover:text-[#00c3eb] transition-colors">{t.label}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
