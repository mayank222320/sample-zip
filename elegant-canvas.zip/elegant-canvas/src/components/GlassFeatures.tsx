/**
 * GlassFeatures v3 — Bento-grid feature showcase
 * Inspired by 21st.dev, Aceternity UI, and MagicUI
 * Live grid background, animated gradient cards, floating particles
 */
import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import {
  ShieldCheck, MapPin, ClipboardCheck, RadioTower, BadgeAlert, Users,
  ArrowUpRight, Zap, Lock, Activity,
} from "lucide-react";
import { AnimatedBeamGrid } from "./AnimatedBeamGrid";

const features = [
  {
    num: "01",
    tag: "Bandobast Command",
    title: "Deploy entire operations from one command map.",
    body: "Assign points, push encrypted orders, manage zones, and track every unit live — all from a single battle-map interface that your HQ controls in real time.",
    icon: ShieldCheck,
    color: "#00c3eb",
    gradient: "from-cyan-500 to-blue-600",
    bg: "from-cyan-950/60 via-blue-950/40 to-slate-950",
    border: "border-cyan-500/20",
    glow: "rgba(0,195,235,0.15)",
    span: "col-span-2",
    bullets: ["Multi-zone point assignment", "Encrypted order dispatch", "Live officer density heat map"],
    img: "/New Images/Overview Dashboard.png",
  },
  {
    num: "02",
    tag: "Live Patrolling",
    title: "Every officer. Every route. Live on your screen.",
    body: "See live GPS positions of every patrolling unit with geo-fence alerts and route deviation tracking.",
    icon: MapPin,
    color: "#10b981",
    gradient: "from-emerald-500 to-teal-500",
    bg: "from-emerald-950/60 via-teal-950/40 to-slate-950",
    border: "border-emerald-500/20",
    glow: "rgba(16,185,129,0.15)",
    span: "col-span-1",
    bullets: ["Real-time GPS · 30s refresh", "Geo-fence breach alerts", "Route compliance analytics"],
    img: "/New Images/Patrolling.png",
  },
  {
    num: "03",
    tag: "Officer Management",
    title: "Your entire force. Fully digital. Fully accounted.",
    body: "Manage officer profiles, rank, designation, shifts, and attendance from a centralized roster.",
    icon: Users,
    color: "#8b5cf6",
    gradient: "from-violet-500 to-indigo-500",
    bg: "from-violet-950/60 via-indigo-950/40 to-slate-950",
    border: "border-violet-500/20",
    glow: "rgba(139,92,246,0.15)",
    span: "col-span-1",
    bullets: ["Digital shift generation", "Auto attendance marking", "Force availability dashboard"],
    img: "/New Images/Officers.png",
  },
  {
    num: "04",
    tag: "Command Escalation",
    title: "Force requests flow up the chain. Precisely.",
    body: "Station-to-ACP-to-DCP-to-CP escalation built into the system. Every request logged, tracked, and fulfilled digitally.",
    icon: RadioTower,
    color: "#f59e0b",
    gradient: "from-amber-500 to-orange-500",
    bg: "from-amber-950/60 via-orange-950/40 to-slate-950",
    border: "border-amber-500/20",
    glow: "rgba(245,158,11,0.15)",
    span: "col-span-1",
    bullets: ["Defined escalation hierarchy", "Force reserve tracking", "Real-time fulfillment status"],
    img: "/New Images/Overview Dashboard.png",
  },
  {
    num: "05",
    tag: "Incident Alerts",
    title: "Nearest officer auto-dispatched. Instantly.",
    body: "AI-driven nearest-officer dispatch uses live GPS to automatically route the closest available unit to any reported incident.",
    icon: BadgeAlert,
    color: "#f43f5e",
    gradient: "from-rose-500 to-pink-500",
    bg: "from-rose-950/60 via-pink-950/40 to-slate-950",
    border: "border-rose-500/20",
    glow: "rgba(244,63,94,0.15)",
    span: "col-span-2",
    bullets: ["Automatic proximity detection", "Push notification dispatch", "Incident resolution tracking"],
    img: "/New Images/Alerts.png",
  },
  {
    num: "06",
    tag: "Digital Paperwork",
    title: "90% of your station diary — automated.",
    body: "Daily duty assignments, muster rolls, bandobast reports auto-generated from live operational data. No typing required.",
    icon: ClipboardCheck,
    color: "#0ea5e9",
    gradient: "from-sky-500 to-cyan-500",
    bg: "from-sky-950/60 via-cyan-950/40 to-slate-950",
    border: "border-sky-500/20",
    glow: "rgba(14,165,233,0.15)",
    span: "col-span-1",
    bullets: ["Auto-generated duty reports", "Digital muster rolls", "One-click export to PDF"],
    img: "/New Images/Overview Dashboard.png",
  },
];

const statsBar = [
  { value: "10K+", label: "Officers", icon: Users, color: "#00c3eb" },
  { value: "99%", label: "Uptime", icon: Activity, color: "#10b981" },
  { value: "AES-256", label: "Encryption", icon: Lock, color: "#8b5cf6" },
  { value: "<30s", label: "GPS Refresh", icon: Zap, color: "#f59e0b" },
];

// Shimmer animation for card border
const ShimmerBorder = ({ color }: { color: string }) => (
  <motion.div
    className="absolute inset-0 rounded-[1.75rem] pointer-events-none"
    style={{
      background: `linear-gradient(90deg, transparent, ${color}40, transparent)`,
      backgroundSize: "200% 100%",
    }}
    animate={{ backgroundPosition: ["200% 0%", "-200% 0%"] }}
    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
  />
);

// Floating orb for card background
const FloatingOrb = ({ color, x, y, size }: { color: string; x: string; y: string; size: number }) => (
  <motion.div
    className="absolute rounded-full pointer-events-none blur-3xl"
    style={{
      left: x,
      top: y,
      width: size,
      height: size,
      background: color,
      opacity: 0,
    }}
    animate={{ opacity: [0.1, 0.25, 0.1], scale: [0.8, 1.2, 0.8] }}
    transition={{ duration: 6 + Math.random() * 4, repeat: Infinity, ease: "easeInOut" }}
  />
);

interface FeatureCardProps {
  feature: typeof features[0];
  index: number;
  isActive: boolean;
  onClick: () => void;
}

const FeatureCard = ({ feature, index, isActive, onClick }: FeatureCardProps) => {
  const Icon = feature.icon;
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40, scale: 0.95 }}
      animate={inView ? { opacity: 1, y: 0, scale: 1 } : {}}
      transition={{ delay: index * 0.08, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={`relative overflow-hidden rounded-[1.75rem] cursor-pointer
        border backdrop-blur-2xl
        transition-all duration-500
        ${feature.span}
        ${isActive ? feature.border : "border-white/8"}
        ${isActive ? "ring-1 ring-inset" : ""}
      `}
      style={{
        background: `linear-gradient(135deg, #0a0f1e, #050a15)`,
        boxShadow: isActive || hovered
          ? `0 0 80px ${feature.glow}, 0 32px 64px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.05)`
          : `0 16px 40px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.03)`,
        ringColor: feature.color,
      }}
    >
      {/* Animated gradient orb background */}
      <FloatingOrb color={feature.glow} x="20%" y="-20%" size={250} />
      <FloatingOrb color={feature.glow} x="60%" y="50%" size={180} />

      {/* Top gradient wash */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          background: `radial-gradient(ellipse at 30% 0%, ${feature.glow}, transparent 60%)`,
        }}
      />

      {/* Active shimmer border */}
      {(isActive || hovered) && <ShimmerBorder color={feature.color} />}

      {/* Content */}
      <div className="relative z-10 p-7 h-full flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between mb-5">
          <div className="flex items-center gap-3">
            <div
              className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ background: `linear-gradient(135deg, ${feature.color}30, ${feature.color}15)`, border: `1px solid ${feature.color}40` }}
            >
              <Icon size={20} style={{ color: feature.color }} />
            </div>
            <div>
              <div className="text-[9px] font-black uppercase tracking-[0.25em] opacity-40 text-white mb-0.5">
                Feature {feature.num}
              </div>
              <div
                className="text-[10px] font-black uppercase tracking-[0.18em]"
                style={{ color: feature.color }}
              >
                {feature.tag}
              </div>
            </div>
          </div>

          <motion.div
            className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: `${feature.color}15`, border: `1px solid ${feature.color}30` }}
            animate={{ rotate: isActive ? 45 : 0 }}
          >
            <ArrowUpRight size={14} style={{ color: feature.color }} />
          </motion.div>
        </div>

        {/* Title */}
        <h3 className="text-lg font-black text-white leading-tight mb-3">
          {feature.title}
        </h3>

        {/* Body */}
        <p className="text-sm text-slate-400 leading-relaxed mb-5 flex-1">
          {feature.body}
        </p>

        {/* Bullets */}
        <AnimatePresence>
          {(isActive || feature.span === "col-span-2") && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-2"
            >
              {feature.bullets.map((b, i) => (
                <motion.div
                  key={b}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.07 }}
                  className="flex items-center gap-2 text-xs text-slate-300"
                >
                  <div
                    className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                    style={{ background: feature.color }}
                  />
                  {b}
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom accent line */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-[2px] rounded-b-[1.75rem]"
          style={{ background: `linear-gradient(90deg, transparent, ${feature.color}, transparent)` }}
          animate={{ opacity: isActive || hovered ? 1 : 0 }}
          transition={{ duration: 0.4 }}
        />
      </div>
    </motion.div>
  );
};

export const GlassFeatures = () => {
  const [activeFeature, setActiveFeature] = useState<number | null>(0);
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const headerInView = useInView(headerRef, { once: true });

  return (
    <section
      ref={sectionRef}
      className="relative py-32 overflow-hidden"
      style={{ background: "linear-gradient(180deg, #030712 0%, #050a1a 50%, #030712 100%)" }}
    >
      {/* Live animated grid background */}
      <AnimatedBeamGrid dark={true} />

      {/* Top fade */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-[#030712] to-transparent pointer-events-none z-10" />
      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#030712] to-transparent pointer-events-none z-10" />

      <div className="relative z-20 container mx-auto px-6 lg:px-8 max-w-[1400px]">
        {/* ── Section header ────────────────────── */}
        <div ref={headerRef} className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={headerInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full mb-6
              bg-cyan-500/10 border border-cyan-500/20 backdrop-blur-xl"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400" />
            </span>
            <span className="text-[10px] font-black uppercase tracking-[0.24em] text-cyan-400">
              Platform Capabilities
            </span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            animate={headerInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="text-4xl md:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.05] mb-5"
          >
            Everything your command{" "}
            <span className="relative">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400">
                needs in one platform.
              </span>
              {/* Underline glow */}
              <motion.span
                className="absolute -bottom-1 left-0 right-0 h-px"
                style={{ background: "linear-gradient(90deg, transparent, #00c3eb, #6366f1, transparent)" }}
                animate={{ opacity: [0.4, 1, 0.4] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={headerInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.7 }}
            className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed"
          >
            Six purpose-built modules that work together seamlessly to digitize every layer of law enforcement operations.
          </motion.p>
        </div>

        {/* ── Live stats bar ────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={headerInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3, duration: 0.7 }}
          className="flex flex-wrap items-center justify-center gap-4 mb-14"
        >
          {statsBar.map((s) => {
            const SIcon = s.icon;
            return (
              <div
                key={s.label}
                className="flex items-center gap-3 px-5 py-3 rounded-2xl backdrop-blur-xl"
                style={{
                  background: `${s.color}12`,
                  border: `1px solid ${s.color}25`,
                }}
              >
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: `${s.color}20` }}
                >
                  <SIcon size={14} style={{ color: s.color }} />
                </div>
                <div>
                  <div className="text-base font-black text-white leading-none">{s.value}</div>
                  <div className="text-[9px] font-bold uppercase tracking-widest text-slate-400">{s.label}</div>
                </div>
              </div>
            );
          })}
        </motion.div>

        {/* ── Bento Grid ────────────────────── */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 auto-rows-auto">
          {features.map((feature, i) => (
            <div
              key={feature.num}
              className={
                // Make first card (col-span-2) and 5th card (col-span-2) span wider on lg
                feature.span === "col-span-2"
                  ? "lg:col-span-2"
                  : "lg:col-span-1"
              }
            >
              <FeatureCard
                feature={feature}
                index={i}
                isActive={activeFeature === i}
                onClick={() => setActiveFeature(activeFeature === i ? null : i)}
              />
            </div>
          ))}
        </div>

        {/* ── Bottom CTA strip ────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.7 }}
          className="mt-16 flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <a
            href="https://calendly.com/admin-copmap/30min"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-3 h-14 px-8 rounded-full text-sm font-bold
              text-white bg-gradient-to-r from-cyan-500 to-blue-600
              shadow-[0_8px_32px_rgba(0,195,235,0.35)]
              hover:shadow-[0_12px_48px_rgba(0,195,235,0.5)]
              hover:-translate-y-0.5 transition-all duration-300"
          >
            <Zap size={16} />
            See All Features Live
            <ArrowUpRight size={16} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
          <div className="text-xs text-slate-500 font-medium">
            No setup fee · 48hr onboarding · Maharashtra-ready
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default GlassFeatures;
