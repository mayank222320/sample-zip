/**
 * GlassHero v4 — ULTRA CINEMATIC
 * Full-viewport dark command center with:
 * - Animated aurora mesh background (CSS)
 * - Giant gradient headline with animated shimmer
 * - Floating cinematic dashboard screenshot  
 * - Live typing effect
 * - Animated orbital rings
 * - Glowing status indicators
 */
import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring, useTransform, AnimatePresence } from "framer-motion";
import { ArrowRight, Play, Shield, MapPin, Lock, ChevronDown, Zap, Activity, Radio } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

// ── Live typing words ─────────────────────────────────────────────────────────
const typingWords = ["bandobast operations.", "live GPS patrolling.", "officer management.", "digital force ops.", "command escalation."];

const TypingEffect = () => {
  const [wordIdx, setWordIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = typingWords[wordIdx];
    let timer: ReturnType<typeof setTimeout>;
    if (!deleting) {
      if (charIdx < word.length) {
        timer = setTimeout(() => setCharIdx(i => i + 1), 60);
      } else {
        timer = setTimeout(() => setDeleting(true), 2200);
      }
    } else {
      if (charIdx > 0) {
        timer = setTimeout(() => setCharIdx(i => i - 1), 32);
      } else {
        setDeleting(false);
        setWordIdx(w => (w + 1) % typingWords.length);
      }
    }
    return () => clearTimeout(timer);
  }, [charIdx, deleting, wordIdx]);

  return (
    <span className="relative">
      <span
        className="font-black"
        style={{
          background: "linear-gradient(135deg, #00c3eb 0%, #818cf8 50%, #c084fc 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
        }}
      >
        {typingWords[wordIdx].slice(0, charIdx)}
      </span>
      <motion.span
        animate={{ opacity: [1, 0] }}
        transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
        className="inline-block w-[3px] h-[0.8em] bg-cyan-400 align-middle ml-1 rounded-sm"
      />
    </span>
  );
};

// ── Orbiting ring component ───────────────────────────────────────────────────
const OrbitRing = ({ radius, duration, delay, dotColor }: { radius: number; duration: number; delay: number; dotColor: string }) => (
  <div
    className="absolute rounded-full border border-white/5 pointer-events-none"
    style={{ width: radius * 2, height: radius * 2, top: `calc(50% - ${radius}px)`, left: `calc(50% - ${radius}px)` }}
  >
    <motion.div
      className="absolute w-2 h-2 rounded-full"
      style={{ background: dotColor, boxShadow: `0 0 8px ${dotColor}, 0 0 20px ${dotColor}60` }}
      animate={{ rotate: 360 }}
      transition={{ duration, repeat: Infinity, ease: "linear", delay }}
      initial={{ rotate: 0 }}
    >
      <div
        className="absolute w-2 h-2 rounded-full"
        style={{
          top: -radius + 4,
          left: -4,
        }}
      />
    </motion.div>
  </div>
);

// ── Dashboard showcase card ───────────────────────────────────────────────────
const DashboardShowcase = () => {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const rotX = useSpring(useTransform(mouseY, [-0.5, 0.5], [8, -8]), { stiffness: 150, damping: 25 });
  const rotY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-10, 10]), { stiffness: 150, damping: 25 });

  const handleMouse = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width - 0.5);
    mouseY.set((e.clientY - rect.top) / rect.height - 0.5);
  };

  return (
    <motion.div
      onMouseMove={handleMouse}
      onMouseLeave={() => { mouseX.set(0); mouseY.set(0); }}
      style={{ rotateX: rotX, rotateY: rotY, transformStyle: "preserve-3d", perspective: 1200 }}
      className="relative w-full max-w-[580px]"
      initial={{ opacity: 0, y: 60, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: 0.6, duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Outer glow rings */}
      <div className="absolute -inset-6 rounded-[2rem] pointer-events-none" style={{ background: "radial-gradient(ellipse, rgba(0,195,235,0.2) 0%, rgba(99,102,241,0.15) 50%, transparent 70%)" }} />

      {/* Main card */}
      <div
        className="relative rounded-[1.5rem] overflow-hidden"
        style={{
          background: "linear-gradient(145deg, rgba(12,20,40,0.97) 0%, rgba(5,10,25,0.98) 100%)",
          border: "1px solid rgba(0,195,235,0.25)",
          boxShadow: "0 40px 100px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,195,235,0.1), inset 0 1px 0 rgba(255,255,255,0.07)",
        }}
      >
        {/* Top accent line */}
        <div style={{ height: "2px", background: "linear-gradient(90deg, #00c3eb, #6366f1, #c084fc, #00c3eb)", backgroundSize: "200%", animation: "gradient-x 4s linear infinite" }} />

        {/* Window bar */}
        <div className="px-5 py-3 flex items-center gap-3 border-b border-white/5" style={{ background: "rgba(0,0,0,0.3)" }}>
          <div className="flex gap-1.5">
            {["#ff5f57", "#febc2e", "#28c840"].map((c, i) => <div key={i} className="w-3 h-3 rounded-full" style={{ background: c }} />)}
          </div>
          <div className="flex-1 flex items-center justify-center gap-2">
            <motion.div
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1.5 h-1.5 rounded-full bg-emerald-400"
            />
            <span className="text-[10px] font-mono text-white/30 tracking-widest uppercase">CopMap · Command Center · LIVE</span>
          </div>
        </div>

        {/* Dashboard screenshot */}
        <div className="relative">
          <img
            src="/hero-dashboard.png"
            alt="CopMap Command Dashboard"
            className="w-full"
            style={{ display: "block" }}
            onError={(e) => {
              // Fallback to original screenshot if generated one doesn't load
              (e.currentTarget as HTMLImageElement).src = "/New Images/Overview Dashboard.png";
              (e.currentTarget as HTMLImageElement).className = "w-full opacity-80";
              (e.currentTarget as HTMLImageElement).style.height = "360px";
              (e.currentTarget as HTMLImageElement).style.objectFit = "cover";
            }}
          />
          {/* Overlay tint */}
          <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 40%, rgba(5,10,25,0.8) 100%)" }} />

          {/* Scan line */}
          <motion.div
            className="absolute left-0 right-0 h-[1px] pointer-events-none"
            style={{ background: "linear-gradient(90deg, transparent, rgba(0,195,235,0.8), transparent)" }}
            animate={{ top: ["0%", "100%"] }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear", repeatDelay: 1.5 }}
          />
        </div>
      </div>

      {/* Floating live badge top-right */}
      <motion.div
        className="absolute -top-3 -right-3 flex items-center gap-2 px-3 py-2 rounded-2xl text-[11px] font-black"
        style={{ background: "rgba(16,185,129,0.15)", border: "1px solid rgba(16,185,129,0.3)", backdropFilter: "blur(12px)", color: "#10b981" }}
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 3, repeat: Infinity }}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        LIVE OPS
      </motion.div>

      {/* Floating stats badge bottom-left */}
      <motion.div
        className="absolute -bottom-4 -left-4 px-4 py-3 rounded-2xl"
        style={{ background: "rgba(5,10,25,0.9)", border: "1px solid rgba(99,102,241,0.3)", backdropFilter: "blur(20px)" }}
        animate={{ y: [0, 6, 0] }}
        transition={{ duration: 4, repeat: Infinity, delay: 1 }}
      >
        <div className="text-2xl font-black" style={{ color: "#818cf8" }}>10K+</div>
        <div className="text-[9px] font-black uppercase tracking-widest text-white/30">Field Officers</div>
      </motion.div>
    </motion.div>
  );
};

// ── Main hero ─────────────────────────────────────────────────────────────────
const GlassHero = () => {
  const heroRef = useRef<HTMLElement>(null);

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
      style={{ background: "#03070f" }}
    >
      {/* ── ANIMATED AURORA BACKGROUND ── */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Primary aurora blob - top left */}
        <motion.div
          className="absolute rounded-full"
          style={{
            width: "800px",
            height: "600px",
            top: "-200px",
            left: "-200px",
            background: "radial-gradient(ellipse, rgba(0,195,235,0.15) 0%, rgba(0,99,150,0.08) 40%, transparent 70%)",
            filter: "blur(60px)",
          }}
          animate={{ x: [0, 60, 0], y: [0, 40, 0], scale: [1, 1.15, 1] }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* Secondary blob - bottom right */}
        <motion.div
          className="absolute rounded-full"
          style={{
            width: "700px",
            height: "700px",
            bottom: "-200px",
            right: "-100px",
            background: "radial-gradient(ellipse, rgba(99,102,241,0.15) 0%, rgba(49,46,129,0.08) 40%, transparent 70%)",
            filter: "blur(80px)",
          }}
          animate={{ x: [0, -50, 0], y: [0, -60, 0], scale: [1, 1.2, 1] }}
          transition={{ duration: 22, repeat: Infinity, ease: "easeInOut", delay: 3 }}
        />
        {/* Mid purple blob */}
        <motion.div
          className="absolute rounded-full"
          style={{
            width: "500px",
            height: "400px",
            top: "30%",
            left: "30%",
            background: "radial-gradient(ellipse, rgba(168,85,247,0.08) 0%, transparent 60%)",
            filter: "blur(60px)",
          }}
          animate={{ x: [0, 80, -40, 0], y: [0, -50, 30, 0], scale: [1, 1.3, 0.9, 1] }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut", delay: 6 }}
        />
      </div>

      {/* ── ANIMATED DOT GRID ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(circle, rgba(0,195,235,0.12) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
          maskImage: "radial-gradient(ellipse 80% 80% at 50% 50%, black 20%, transparent 100%)",
          WebkitMaskImage: "radial-gradient(ellipse 80% 80% at 50% 50%, black 20%, transparent 100%)",
        }}
      />

      {/* ── HORIZONTAL SCAN LINE ── */}
      <motion.div
        className="absolute left-0 right-0 h-px pointer-events-none z-10"
        style={{ background: "linear-gradient(90deg, transparent 0%, rgba(0,195,235,0.4) 30%, rgba(99,102,241,0.4) 70%, transparent 100%)" }}
        animate={{ top: ["0%", "100%"] }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear", repeatDelay: 3 }}
      />

      {/* ── CONTENT ── */}
      <div className="relative z-20 container mx-auto px-6 lg:px-10 max-w-[1440px] pt-28 pb-20">
        <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-10">

          {/* LEFT — Text block */}
          <div className="flex-1 max-w-[640px] text-center lg:text-left">

            {/* Live pill */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full mb-8 text-[11px] font-black uppercase tracking-[0.2em]"
              style={{
                background: "rgba(0,195,235,0.08)",
                border: "1px solid rgba(0,195,235,0.25)",
                color: "#00c3eb",
              }}
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              Live in Maharashtra · MeitY Recognised
            </motion.div>

            {/* GIANT HEADLINE */}
            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              className="font-black leading-[1.0] tracking-[-0.03em] mb-4"
              style={{ fontSize: "clamp(3.2rem, 8vw, 7rem)", color: "#ffffff" }}
            >
              Plan.{" "}
              <span style={{ background: "linear-gradient(135deg, #00c3eb, #6366f1)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>Deploy.</span>
              <br />
              Monitor.{" "}
              <span style={{ color: "rgba(255,255,255,0.25)", fontWeight: 300 }}>Audit.</span>
            </motion.h1>

            {/* Gradient accent line */}
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.7, duration: 1, ease: [0.22, 1, 0.36, 1] }}
              className="h-0.5 rounded-full mb-8 lg:mb-8 mx-auto lg:mx-0 max-w-xs lg:max-w-sm origin-left"
              style={{ background: "linear-gradient(90deg, #00c3eb, #6366f1, transparent)" }}
            />

            {/* Tagline with typing */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-lg md:text-xl leading-relaxed mb-4 max-w-lg mx-auto lg:mx-0"
              style={{ color: "rgba(255,255,255,0.45)" }}
            >
              India's only command platform for{" "}
              <TypingEffect />
            </motion.p>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="text-sm mb-12 max-w-md mx-auto lg:mx-0"
              style={{ color: "rgba(255,255,255,0.2)" }}
            >
              Trusted from station to state — real-time GPS · AES-256 encryption · 48hr onboarding
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9, duration: 0.7 }}
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 mb-12"
            >
              {/* Primary CTA */}
              <motion.a
                href="https://calendly.com/admin-copmap/30min"
                target="_blank" rel="noopener noreferrer"
                className="group relative flex items-center gap-3 h-14 px-8 rounded-full font-bold text-sm text-white overflow-hidden"
                style={{
                  background: "linear-gradient(135deg, #0096b5 0%, #2563eb 100%)",
                  boxShadow: "0 0 0 1px rgba(0,195,235,0.3), 0 8px 32px rgba(0,195,235,0.35), inset 0 1px 0 rgba(255,255,255,0.15)",
                }}
                whileHover={{ scale: 1.04, boxShadow: "0 0 0 1px rgba(0,195,235,0.6), 0 12px 48px rgba(0,195,235,0.5), inset 0 1px 0 rgba(255,255,255,0.2)" }}
                whileTap={{ scale: 0.97 }}
              >
                <Zap size={16} />
                Request Live Demo
                <motion.span
                  className="group-hover:translate-x-1 transition-transform duration-200"
                >
                  <ArrowRight size={16} />
                </motion.span>
              </motion.a>

              {/* Secondary CTA */}
              <motion.a
                href="https://drive.google.com/file/d/16ZrLH4Zp5Umc7hI2i-xDVt_XCyBDFeLN/view"
                target="_blank" rel="noopener noreferrer"
                className="group flex items-center gap-3 h-14 px-8 rounded-full font-bold text-sm"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  color: "rgba(255,255,255,0.7)",
                }}
                whileHover={{ background: "rgba(255,255,255,0.08)", borderColor: "rgba(255,255,255,0.2)", scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                <motion.div
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ background: "rgba(0,195,235,0.15)", border: "1px solid rgba(0,195,235,0.25)" }}
                  whileHover={{ scale: 1.15, background: "rgba(0,195,235,0.25)" }}
                >
                  <Play size={13} className="ml-0.5" style={{ color: "#00c3eb" }} />
                </motion.div>
                Watch How It Works
              </motion.a>
            </motion.div>

            {/* Trust row */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
              className="flex flex-wrap items-center justify-center lg:justify-start gap-x-7 gap-y-3"
            >
              {[
                { icon: Shield, text: "Gov-Grade Encrypted" },
                { icon: MapPin, text: "Live in Maharashtra" },
                { icon: Lock, text: "Role-Based Access" },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-2 text-xs font-medium" style={{ color: "rgba(255,255,255,0.28)" }}>
                  <Icon size={13} style={{ color: "#00c3eb" }} />
                  {text}
                </div>
              ))}
            </motion.div>
          </div>

          {/* RIGHT — Dashboard showcase */}
          <div className="flex-1 flex justify-center lg:justify-end relative">
            <DashboardShowcase />
          </div>
        </div>

        {/* ── BOTTOM STATS BAR ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          {[
            { value: "10K+", label: "Field Officers", color: "#00c3eb", icon: Activity },
            { value: "250+", label: "Active Nodes", color: "#8b5cf6", icon: Radio },
            { value: "1K+", label: "Daily Patrols", color: "#10b981", icon: MapPin },
            { value: "99%", label: "Platform Uptime", color: "#f59e0b", icon: Zap },
          ].map((s, i) => {
            const SIcon = s.icon;
            return (
              <motion.div
                key={s.label}
                className="relative overflow-hidden rounded-2xl p-5 text-center"
                style={{
                  background: `linear-gradient(135deg, ${s.color}10, rgba(5,10,25,0.8))`,
                  border: `1px solid ${s.color}20`,
                }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 + i * 0.08 }}
                whileHover={{ y: -3, borderColor: `${s.color}40` }}
              >
                <div className="absolute top-0 left-0 right-0 h-px" style={{ background: `linear-gradient(90deg, transparent, ${s.color}50, transparent)` }} />
                <SIcon size={16} style={{ color: s.color, margin: "0 auto 8px" }} />
                <div className="text-2xl font-black" style={{ color: s.color }}>{s.value}</div>
                <div className="text-[9px] font-black uppercase tracking-widest mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>{s.label}</div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-5 h-9 rounded-full flex justify-center pt-1.5"
          style={{ border: "1px solid rgba(255,255,255,0.15)" }}
        >
          <div className="w-0.5 h-2.5 rounded-full" style={{ background: "rgba(0,195,235,0.7)" }} />
        </motion.div>
        <ChevronDown size={12} style={{ color: "rgba(255,255,255,0.2)" }} className="animate-bounce" />
      </motion.div>
    </section>
  );
};

export default GlassHero;
