/**
 * GlassStats v3 — Dark glassmorphism stats section
 * Inspired by MagicUI & 21st.dev - animated counters, glowing cards, live pulses
 */
import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Activity, MapPin, Clock, Shield, Zap, Users, ArrowUpRight } from "lucide-react";
import { AnimatedBeamGrid } from "./AnimatedBeamGrid";

const stats = [
  {
    value: 10000,
    suffix: "+",
    label: "Field Officers",
    sublabel: "Across Maharashtra",
    icon: Users,
    color: "#00c3eb",
    gradient: "from-cyan-500 to-blue-500",
  },
  {
    value: 250,
    suffix: "+",
    label: "Active Nodes",
    sublabel: "Stations & Units",
    icon: MapPin,
    color: "#8b5cf6",
    gradient: "from-violet-500 to-indigo-500",
  },
  {
    value: 1000,
    suffix: "+",
    label: "Daily Patrols",
    sublabel: "Logged & Tracked",
    icon: Activity,
    color: "#10b981",
    gradient: "from-emerald-500 to-teal-500",
  },
  {
    value: 99,
    suffix: "%",
    label: "Live Visibility",
    sublabel: "Platform Uptime SLA",
    icon: Zap,
    color: "#f59e0b",
    gradient: "from-amber-500 to-orange-500",
  },
];

const highlights = [
  {
    icon: Clock,
    title: "Setup in Under 48 Hours",
    body: "Full station onboarding, officer registration, and live map deployment — ready in 2 days flat.",
    tag: "Speed",
    color: "#00c3eb",
  },
  {
    icon: Shield,
    title: "256-bit Encrypted Operations",
    body: "All officer positions, deployment orders, and incident data are encrypted end-to-end at the hardware level.",
    tag: "Security",
    color: "#8b5cf6",
  },
  {
    icon: MapPin,
    title: "GPS Tamper Detection",
    body: "Any disconnect, spoofing attempt, or device manipulation is instantly flagged and logged for review.",
    tag: "Integrity",
    color: "#10b981",
  },
];

// Animated number counter
function AnimatedCounter({ target, suffix, trigger }: { target: number; suffix: string; trigger: boolean }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!trigger) return;
    const dur = 2500;
    const t0 = performance.now();
    const run = (now: number) => {
      const p = Math.min((now - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 4);
      const current = Math.round(eased * target);
      setVal(current);
      if (p < 1) requestAnimationFrame(run);
    };
    requestAnimationFrame(run);
  }, [trigger, target]);

  const display = target >= 1000 ? (val >= 1000 ? `${(val / 1000).toFixed(1)}K` : val.toString()) : val.toString();

  return <>{display}{suffix}</>;
}

export const GlassStats = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const inView = useInView(sectionRef as React.RefObject<Element>, { once: true, margin: "-100px" });

  return (
    <section
      ref={sectionRef}
      className="relative py-32 overflow-hidden"
      style={{ background: "linear-gradient(180deg, #020b16 0%, #030f1e 50%, #020b16 100%)" }}
    >
      {/* Animated beam grid */}
      <AnimatedBeamGrid dark={true} />

      {/* Radial glow */}
      <div className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 80% 50% at 50% 60%, rgba(0,99,150,0.08) 0%, transparent 70%)" }} />

      <div className="relative z-10 container mx-auto px-6 lg:px-8 max-w-[1400px]">

        {/* Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6"
            style={{ background: "rgba(0,195,235,0.08)", border: "1px solid rgba(0,195,235,0.2)" }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-[0.22em] text-cyan-400">Live Platform Metrics</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="text-4xl md:text-5xl font-black text-white tracking-tight mb-4"
          >
            Numbers that command{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">respect.</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.7 }}
            className="text-white/40 text-lg max-w-xl mx-auto"
          >
            Real metrics from live deployments across Maharashtra and beyond.
          </motion.p>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 40, scale: 0.92 }}
                animate={inView ? { opacity: 1, y: 0, scale: 1 } : {}}
                transition={{ delay: i * 0.1, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -4, scale: 1.02 }}
                className="relative overflow-hidden rounded-[1.5rem] p-6 lg:p-8 cursor-default group"
                style={{
                  background: `linear-gradient(135deg, ${stat.color}10, transparent)`,
                  border: `1px solid ${stat.color}20`,
                  backdropFilter: "blur(20px)",
                }}
              >
                {/* Inner glow on hover */}
                <motion.div
                  className="absolute inset-0 rounded-[1.5rem] pointer-events-none"
                  animate={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  style={{ background: `radial-gradient(circle at 50% 0%, ${stat.color}15, transparent 70%)` }}
                />

                {/* Top accent line */}
                <div className="absolute top-0 left-4 right-4 h-px"
                  style={{ background: `linear-gradient(90deg, transparent, ${stat.color}60, transparent)` }} />

                {/* Icon */}
                <div
                  className="w-11 h-11 rounded-2xl flex items-center justify-center mb-5"
                  style={{ background: `${stat.color}15`, border: `1px solid ${stat.color}30` }}
                >
                  <Icon size={20} style={{ color: stat.color }} />
                </div>

                {/* Counter */}
                <div
                  className="text-4xl lg:text-5xl font-black mb-2 tabular-nums"
                  style={{ color: stat.color, textShadow: `0 0 40px ${stat.color}40` }}
                >
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} trigger={inView} />
                </div>

                <div className="text-sm font-black text-white/80 mb-1">{stat.label}</div>
                <div className="text-xs text-white/30 font-medium">{stat.sublabel}</div>

                {/* Corner accent */}
                <div
                  className="absolute bottom-4 right-4 w-6 h-6 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center"
                  style={{ background: `${stat.color}20`, border: `1px solid ${stat.color}40` }}
                >
                  <ArrowUpRight size={12} style={{ color: stat.color }} />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Highlight cards */}
        <div className="grid md:grid-cols-3 gap-4">
          {highlights.map((h, i) => {
            const HIcon = h.icon;
            return (
              <motion.div
                key={h.title}
                initial={{ opacity: 0, x: -30 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: 0.4 + i * 0.12, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -3 }}
                className="relative overflow-hidden rounded-[1.5rem] p-7 group cursor-default"
                style={{
                  background: `linear-gradient(135deg, ${h.color}08, rgba(5,10,25,0.8))`,
                  border: `1px solid ${h.color}18`,
                  backdropFilter: "blur(20px)",
                }}
              >
                {/* Glow on hover */}
                <motion.div
                  className="absolute inset-0 rounded-[1.5rem] pointer-events-none"
                  animate={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                  style={{ background: `radial-gradient(ellipse at 20% 50%, ${h.color}12, transparent 70%)` }}
                />

                {/* Tag chip */}
                <div
                  className="inline-flex items-center px-3 py-1 rounded-full mb-4 text-[9px] font-black uppercase tracking-widest"
                  style={{ background: `${h.color}15`, border: `1px solid ${h.color}25`, color: h.color }}
                >
                  {h.tag}
                </div>

                {/* Icon */}
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center mb-5"
                  style={{ background: `${h.color}15`, border: `1px solid ${h.color}25` }}
                >
                  <HIcon size={22} style={{ color: h.color }} />
                </div>

                <h3 className="text-base font-black text-white mb-3">{h.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">{h.body}</p>

                {/* Bottom accent */}
                <div
                  className="absolute bottom-0 left-8 right-8 h-px"
                  style={{ background: `linear-gradient(90deg, transparent, ${h.color}30, transparent)` }}
                />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default GlassStats;
