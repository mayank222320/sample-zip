import { useRef } from "react";

interface MarqueeTickerProps {
    items: { text: string; highlight?: boolean }[];
    speed?: "slow" | "normal" | "fast";
    dark?: boolean;
}

const speeds = { slow: "50s", normal: "32s", fast: "20s" };

const MarqueeTicker = ({ items, speed = "normal", dark = false }: MarqueeTickerProps) => {
    const doubled = [...items, ...items];

    return (
        <div className="relative overflow-hidden">
            {/* Left fade edge */}
            <div className={`absolute left-0 top-0 bottom-0 w-32 z-10 pointer-events-none ${
                dark
                    ? "bg-gradient-to-r from-slate-100 dark:from-[#060F1E] to-transparent"
                    : "bg-gradient-to-r from-slate-100 dark:from-[#0A192F] to-transparent"
            }`} />
            {/* Right fade edge */}
            <div className={`absolute right-0 top-0 bottom-0 w-32 z-10 pointer-events-none ${
                dark
                    ? "bg-gradient-to-l from-slate-100 dark:from-[#060F1E] to-transparent"
                    : "bg-gradient-to-l from-slate-100 dark:from-[#0A192F] to-transparent"
            }`} />

            <div
                className="flex w-max animate-marquee"
                style={{ animationDuration: speeds[speed] }}
            >
                {doubled.map((item, i) => (
                    <div key={i} className="flex items-center shrink-0">
                        {item.highlight ? (
                            <span className="mx-3 px-4 py-1.5 rounded-full text-[11px] font-bold uppercase tracking-[0.14em] whitespace-nowrap bg-[#00a2c7]/15 border border-[#00a2c7]/30 text-[#00c3eb] shadow-[0_0_12px_rgba(0,162,199,0.15)]">
                                {item.text}
                            </span>
                        ) : (
                            <span className="mx-3 text-[11px] font-semibold uppercase tracking-[0.14em] whitespace-nowrap text-slate-600 dark:text-slate-400/70">
                                {item.text}
                            </span>
                        )}
                        {/* Separator dot */}
                        <span className="text-[8px] text-[#00a2c7]/25 select-none">●</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MarqueeTicker;
