import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./theme/ThemeToggle";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "Product", path: "/product" },
  { name: "Features", path: "/features" },
  { name: "About", path: "/about" },
  { name: "Contact", path: "/contact" },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isCompact, setIsCompact] = useState(false);
  const isCompactRef = useRef(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      const isDesktop = window.innerWidth >= 1280;
      if (!isDesktop) {
        isCompactRef.current = false;
        setIsCompact(false);
        return;
      }
      const compact = window.scrollY > 300;
      isCompactRef.current = compact;
      setIsCompact(compact);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, []);

  // On route change: restore compact state from ref without waiting for scroll event
  useEffect(() => {
    setIsCompact(isCompactRef.current);
    setIsOpen(false);
  }, [location.pathname]);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 py-4">
      <div className={`mx-auto transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] ${isCompact ? "w-fit px-4" : "w-full max-w-7xl px-4 lg:px-8"
        }`}>
        <div className={`h-14 lg:h-16 rounded-full border transform-gpu backdrop-blur-3xl transition-all duration-700 ${isCompact
          ? "bg-[#030f1e]/90 border-cyan-500/15 shadow-[0_8px_32px_rgba(0,0,0,0.5),0_0_0_1px_rgba(0,195,235,0.08)] px-4 lg:px-5"
          : "bg-[#030f1e]/70 border-white/8 shadow-[0_4px_24px_rgba(0,0,0,0.4)] px-4 lg:px-6"
          }`} style={{ willChange: 'transform' }}>
          <div className={`flex items-center h-full transition-all duration-700 ${isCompact ? "justify-center gap-2 lg:gap-3" : "justify-between gap-4"
            }`}>

            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="relative flex items-center justify-center rounded-full transition-all duration-300 group-hover:shadow-[0_0_20px_rgba(56,189,248,0.4)] bg-transparent">
                <img src="/Copmap-logo.png" alt="CopMap" className="h-9 w-9 object-contain relative z-10 group-hover:scale-105 transition-transform duration-300" />
              </div>
              <div className={`flex flex-col leading-none overflow-hidden transition-all duration-700 ${isCompact ? "max-w-0 opacity-0" : "max-w-[220px] opacity-100"
                }`}>
                <span className="text-[17px] font-heading font-bold tracking-tight text-white group-hover:text-[#00a2c7] transition-colors">
                  CopMap
                </span>
                <span className="text-[10px] hidden sm:block text-slate-400">
                  Revolutionizing Police Operations
                </span>
              </div>
            </Link>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-1 px-2 py-1.5 relative">
              {navLinks.map((link) => {
                const isActive = location.pathname === link.path;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`relative px-4 py-2 rounded-full text-sm font-medium z-10 transition-colors outline-none ${isActive ? "text-[#050B14] font-bold" : "text-[#00c3eb] hover:text-white"
                      }`}
                    style={{ WebkitTapHighlightColor: 'transparent' }}
                  >
                    {isActive && (
                      <motion.div
                        key={link.path}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.2, ease: "easeOut" }}
                        className="absolute inset-0 rounded-full bg-[#00c3eb] shadow-[0_0_12px_rgba(0,195,235,0.35)] -z-10"
                      />
                    )}
                    {link.name}
                  </Link>
                );
              })}
            </div>

            {/* CTA */}
            <div className="hidden lg:flex items-center gap-3">
              <ThemeToggle />
              <Button variant="cta" className={`rounded-full transition-all ${isCompact ? "px-5" : "px-7"
                }`} asChild>
                <a href="https://calendly.com/admin-copmap/30min" target="_blank" rel="noopener noreferrer">Request a Demo</a>
              </Button>
            </div>

            {/* Mobile nav items */}
            <div className="flex lg:hidden items-center gap-3">
              <ThemeToggle />
              <button
                className="p-2 rounded-full shadow-sm transition-all text-white bg-white/10 border border-white/20"
                onClick={() => setIsOpen(!isOpen)}
                aria-label="Toggle menu"
              >
                {isOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="lg:hidden overflow-hidden"
            >
              <div className="pb-4 mt-2 mb-4 bg-[#050B14]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-xl">
                <div className="flex flex-col gap-1 p-3">
                  {navLinks.map((link, i) => (
                    <motion.div
                      key={link.path}
                      initial={{ opacity: 0, x: -16 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.04 }}
                    >
                      <Link
                        to={link.path}
                        onClick={() => setIsOpen(false)}
                        className={`px-4 py-3 rounded-xl text-sm font-medium transition-colors block ${location.pathname === link.path
                          ? "text-[#050B14] bg-[#00c3eb] font-bold"
                          : "text-[#00c3eb] hover:bg-[#00c3eb]/10 hover:text-white"
                          }`}
                      >
                        {link.name}
                      </Link>
                    </motion.div>
                  ))}
                  <motion.div
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: navLinks.length * 0.04 }}
                    className="pt-2 px-2"
                  >
                    <Button variant="cta" className="w-full rounded-xl" asChild>
                      <a href="https://calendly.com/admin-copmap/30min" target="_blank" rel="noopener noreferrer">Request a Demo</a>
                    </Button>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
};

export default Navbar;
