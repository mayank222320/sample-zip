import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { motion } from "framer-motion";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "group inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 relative overflow-hidden",
  {
    variants: {
      variant: {
        default: "bg-[#00c3eb] text-[#050B14] hover:bg-[#00c3eb]/90 font-semibold",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        cta: "bg-gradient-to-r from-[#00c3eb] via-[#00d4ff] to-[#00c3eb] text-[#050B14] font-semibold transition-all duration-300",
        "outline-hero": "border-2 border-white text-white hover:bg-white/10 hover:border-[#00c3eb] transition-all duration-200 backdrop-blur-md",
        "outline-light": "border-2 border-[#050B14] text-[#050B14] transition-all duration-300 font-semibold",
      },
      size: {
        default: "h-12 px-6 py-2.5",
        sm: "h-10 px-4 text-xs",
        lg: "h-14 px-10 text-[16px]",
        icon: "h-12 w-12",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
  VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  icon?: React.ElementType;
  iconPosition?: "left" | "right";
  animate?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, icon: Icon, iconPosition = "right", animate = true, children, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";

    // If we're not animating, just render the plain button logic
    if (!animate) {
      return (
        <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props}>
          {Icon && iconPosition === "left" && <Icon className="size-4" />}
          {children}
          {Icon && iconPosition === "right" && <Icon className="size-4" />}
        </Comp>
      );
    }

    // Magical animation variants
    const textVariants = {
      initial: { y: 0, color: "inherit" },
      hover: { y: -2, color: "#050B14", transition: { duration: 0.8, ease: "easeOut" } }
    };

    const iconVariants = {
      initial: { x: 0, opacity: 0.8, color: "inherit" },
      hover: { x: 5, opacity: 1, color: "#050B14", transition: { duration: 0.8, ease: "easeOut" } }
    };

    const iconVariantsLeft = {
      initial: { x: 0, opacity: 0.8, color: "inherit" },
      hover: { x: -5, opacity: 1, color: "#050B14", transition: { duration: 0.8, ease: "easeOut" } }
    };

    const fillVariants = {
      initial: { scale: 0, opacity: 0 },
      hover: { scale: 1.5, opacity: 1, transition: { duration: 1.2, ease: [0.22, 1, 0.36, 1] } }
    };

    return (
      <Comp
        className={cn(
          buttonVariants({ variant, size, className }), 
          "active:scale-95 group hover:border-[#00c3eb]",
          // Add border-2 if the variant doesn't already have a border (like cta and default)
          !variant?.includes("outline") && "border-2 border-transparent"
        )}
        ref={ref}
        {...props}
      >
        <motion.div
          className="relative z-10 flex items-center justify-center gap-2 h-full w-full"
          initial="initial"
          whileHover="hover"
          animate="initial"
        >
          {/* Expanding white fill animation */}
          <motion.div 
            variants={fillVariants}
            className="absolute inset-[-2px] bg-white rounded-full -z-10 pointer-events-none origin-center"
          />

          {/* Subtle background glow effect on hover */}
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-0" />

          {Icon && iconPosition === "left" && (
            <motion.span variants={iconVariantsLeft} className="flex-shrink-0 relative z-20">
              <Icon className="size-4 lg:size-[18px]" />
            </motion.span>
          )}

          <motion.span
            className="inline-block whitespace-nowrap relative z-20"
            variants={textVariants}
          >
            {children}
          </motion.span>

          {Icon && iconPosition === "right" && (
            <motion.span variants={iconVariants} className="flex-shrink-0 relative z-20">
              <Icon className="size-4 lg:size-[18px]" />
            </motion.span>
          )}
        </motion.div>
      </Comp>
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };

