import { Link } from "react-router-dom";
import { motion, AnimatePresence, useInView } from "framer-motion";
import { ArrowRight, ChevronDown, Zap, Shield, Globe, Smartphone, Monitor, MapPin, Activity, Lock, Radio } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PageTransition from "@/components/PageTransition";
import MarqueeTicker from "@/components/MarqueeTicker";
import { useState, useEffect, useRef } from "react";
import SEOHead from "@/components/seo/SEOHead";
import { FAQSchema } from "@/components/seo/StructuredData";
import { GlassStats } from "@/components/GlassStats";
import { GlassFeatures } from "@/components/GlassFeatures";
import { EcosystemLayers3D } from "@/components/EcosystemLayers3D";
import GlassHero from "@/components/GlassHero";

const tickerItems = [
  { text: "Live GPS Tracking" },
  { text: "Bandobast Management", highlight: true },
  { text: "Minimal Paperwork" },
  { text: "Strategic Deployment", highlight: true },
  { text: "Patrolling Operations" },
  { text: "Active in Law Enforcement", highlight: true },
  { text: "Attendance Automation" },
  { text: "Resource Escalation" },
  { text: "Endorsed by Top Brass", highlight: true },
  { text: "Real-Time Command" },
];

const faqItems = [
  { q: "Is the operational data secured?", a: "Yes. All operational data is heavily encrypted at rest and in transit, hosted securely in compliance with strict law enforcement infosec guidelines." },
  { q: "Can field officers tamper with the GPS?", a: "No. The CopMap system utilizes tamper-evident tracking technology and instantly logs all disconnects for immediate administrative review." },
  { q: "Does this replace manual station diaries?", a: "Yes. CopMap integrates duty assignments with automated shift generation, completely digitizing 90% of tedious manual paperwork." },
  { q: "What is the deployment timeline?", a: "Initial command center setup takes typically 2-3 days, with full field personnel onboarded and trained in under two weeks." }
];

// ── Animated number ───────────────────────────────────────────────────────────
const AnimatedNumber = ({ count, suffix, shouldStart }: { count: number; suffix: string; shouldStart: boolean }) => {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!shouldStart) return;
    const dur = 2200;
    const t0 = performance.now();
    const run = (now: number) => {
      const p = Math.min((now - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(eased * count));
      if (p < 1) requestAnimationFrame(run);
    };
    requestAnimationFrame(run);
  }, [shouldStart, count]);
  return <>{val}{suffix}</>;
};

// ── How It Works Section ──────────────────────────────────────────────────────
const HowItWorksSection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<Element>, { once: true, margin: "-100px" });

  const steps = [
    { num: "01", title: "Station Onboarding", body: "Register your station, import officer roster, and configure patrol zones — all in under 48 hours." },
    { num: "02", title: "Deploy to the Field", body: "Officers download the mobile app, check in digitally, and begin GPS-verified patrols instantly." },
    { num: "03", title: "Monitor in Real Time", body: "Command center sees every officer, every route, every alert — live on an interactive map." },
    { num: "04", title: "Audit & Report", body: "Auto-generated muster rolls, duty logs, and patrol reports available instantly for review." },
  ];

  return (
    <section className="relative py-32 overflow-hidden" style={{ background: "linear-gradient(180deg, #030712 0%, #040d1a 50%, #030712 100%)" }}>
      {/* Dot grid */}
      <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle, rgba(0,195,235,0.08) 1px, transparent 1px)", backgroundSize: "48px 48px" }} />
      <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse 60% 60% at 50% 50%, rgba(0,50,80,0.15) 0%, transparent 70%)" }} />

      <div ref={ref} className="relative z-10 container mx-auto px-6 lg:px-10 max-w-[1200px]">
        {/* Header */}
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6 text-[10px] font-black uppercase tracking-[0.22em]"
            style={{ background: "rgba(0,195,235,0.08)", border: "1px solid rgba(0,195,235,0.2)", color: "#00c3eb" }}
          >
            <Zap size={11} />
            Platform Workflow
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="text-4xl md:text-5xl font-black text-white tracking-tight mb-4"
          >
            Live in{" "}
            <span style={{ background: "linear-gradient(135deg, #00c3eb, #818cf8)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
              4 simple steps.
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ delay: 0.2 }}
            className="text-white/40 text-lg max-w-xl mx-auto"
          >
            No server setup. No complex IT. Just onboard and go live.
          </motion.p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((step, i) => (
            <motion.div
              key={step.num}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2 + i * 0.12, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -4 }}
              className="relative overflow-hidden rounded-[1.5rem] p-7 group cursor-default"
              style={{
                background: "linear-gradient(145deg, rgba(0,195,235,0.05), rgba(5,10,25,0.8))",
                border: "1px solid rgba(0,195,235,0.1)",
              }}
            >
              {/* Hover glow */}
              <motion.div
                className="absolute inset-0 rounded-[1.5rem] pointer-events-none"
                animate={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
                style={{ background: "radial-gradient(circle at 50% 0%, rgba(0,195,235,0.1), transparent 70%)" }}
              />
              <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(0,195,235,0.4), transparent)" }} />

              {/* Number */}
              <div className="text-5xl font-black mb-4" style={{ color: "rgba(0,195,235,0.15)" }}>{step.num}</div>
              <h3 className="text-base font-black text-white mb-3">{step.title}</h3>
              <p className="text-sm text-white/35 leading-relaxed">{step.body}</p>

              {/* Arrow connector */}
              {i < steps.length - 1 && (
                <div className="absolute top-1/2 -right-2 hidden lg:flex items-center z-10">
                  <ArrowRight size={14} style={{ color: "rgba(0,195,235,0.3)" }} />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ── FAQ Section ───────────────────────────────────────────────────────────────
const FAQSection = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<Element>, { once: true, margin: "-80px" });

  return (
    <section className="relative py-28 overflow-hidden" style={{ background: "linear-gradient(180deg, #020b16 0%, #030712 100%)" }}>
      <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.03) 1px, transparent 1px)", backgroundSize: "28px 28px" }} />

      <div ref={ref} className="container mx-auto px-6 lg:px-12 max-w-4xl relative z-10">
        <div className="text-center mb-14">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center px-3 py-1.5 rounded-full mb-5 text-[10px] font-black uppercase tracking-[0.2em]"
            style={{ background: "rgba(0,195,235,0.08)", border: "1px solid rgba(0,195,235,0.2)", color: "#00c3eb" }}
          >
            Knowledge Base
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            className="text-3xl lg:text-4xl font-black text-white tracking-tight mt-2"
          >
            Common questions,{" "}
            <span style={{ background: "linear-gradient(135deg, #00c3eb, #818cf8)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
              answered.
            </span>
          </motion.h2>
        </div>

        <div className="space-y-3">
          {faqItems.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.09, duration: 0.5 }}
              className={`relative rounded-[1.25rem] border overflow-hidden transition-all duration-350 ${
                openFaq === i
                  ? "border-cyan-500/30"
                  : "border-white/8 hover:border-white/15"
              }`}
              style={{ background: openFaq === i ? "rgba(0,195,235,0.05)" : "rgba(5,10,25,0.5)" }}
            >
              {openFaq === i && (
                <motion.div layoutId="faq-accent" className="absolute left-0 top-3 bottom-3 w-0.5 rounded-full" style={{ background: "linear-gradient(to bottom, #00c3eb, #6366f1)" }} />
              )}
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <span className={`text-base font-heading font-bold transition-colors duration-200 pr-4 ${openFaq === i ? "text-white" : "text-slate-300"}`}>
                  {faq.q}
                </span>
                <motion.div
                  animate={{ rotate: openFaq === i ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex-shrink-0 w-7 h-7 rounded-full border flex items-center justify-center"
                  style={{
                    background: openFaq === i ? "rgba(0,195,235,0.15)" : "rgba(255,255,255,0.04)",
                    borderColor: openFaq === i ? "rgba(0,195,235,0.4)" : "rgba(255,255,255,0.1)",
                  }}
                >
                  <ChevronDown size={14} style={{ color: openFaq === i ? "#00c3eb" : "rgba(255,255,255,0.4)" }} />
                </motion.div>
              </button>
              <AnimatePresence>
                {openFaq === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.27 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6 pt-0 border-t border-white/8">
                      <div className="pt-4 text-sm text-slate-400 leading-relaxed pl-2">{faq.a}</div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="mt-16 text-center"
        >
          <p className="text-white/25 text-sm mb-6">Ready to modernize your force operations?</p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2.5 h-12 px-8 rounded-full font-bold text-sm text-white"
            style={{ background: "linear-gradient(135deg, #0096b5, #2563eb)", boxShadow: "0 8px 24px rgba(0,195,235,0.3)" }}
          >
            Get Started
            <ArrowRight size={15} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

// ── CTA Section ───────────────────────────────────────────────────────────────
const CTASection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<Element>, { once: true });

  return (
    <section className="relative py-28 overflow-hidden" style={{ background: "#030712" }}>
      {/* Aurora glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute rounded-full"
          style={{ width: "600px", height: "600px", top: "-100px", left: "50%", transform: "translateX(-50%)", background: "radial-gradient(ellipse, rgba(0,195,235,0.12) 0%, transparent 70%)", filter: "blur(60px)" }}
          animate={{ scale: [1, 1.2, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>
      <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle, rgba(0,195,235,0.06) 1px, transparent 1px)", backgroundSize: "40px 40px" }} />

      <div ref={ref} className="relative z-10 container mx-auto px-6 max-w-[900px]">
        <div
          className="relative overflow-hidden rounded-[2rem] p-12 lg:p-20 text-center"
          style={{
            background: "linear-gradient(145deg, rgba(0,195,235,0.06), rgba(99,102,241,0.06), rgba(5,10,25,0.9))",
            border: "1px solid rgba(0,195,235,0.15)",
            boxShadow: "0 0 80px rgba(0,195,235,0.08), inset 0 1px 0 rgba(255,255,255,0.05)",
          }}
        >
          {/* Top shimmer */}
          <div className="absolute top-0 left-1/4 right-1/4 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(0,195,235,0.5), transparent)" }} />
          <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle, rgba(0,195,235,0.04) 1px, transparent 1px)", backgroundSize: "24px 24px" }} />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8 text-[10px] font-black uppercase tracking-widest"
            style={{ background: "rgba(0,195,235,0.12)", border: "1px solid rgba(0,195,235,0.25)", color: "#00c3eb" }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            Start Your Deployment
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            className="text-4xl lg:text-5xl font-black text-white tracking-tight mb-5 leading-tight"
          >
            Ready to command your force{" "}
            <span style={{ background: "linear-gradient(135deg, #00c3eb, #818cf8)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
              with precision?
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ delay: 0.2 }}
            className="text-lg text-white/35 mb-12 leading-relaxed max-w-xl mx-auto"
          >
            Join Maharashtra's live police operations network. Setup in 48 hours. Full station onboarding. Zero infrastructure cost.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10"
          >
            <a
              href="https://calendly.com/admin-copmap/30min"
              target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2.5 h-14 px-8 rounded-full font-bold text-sm text-white"
              style={{ background: "linear-gradient(135deg, #0096b5, #2563eb)", boxShadow: "0 8px 32px rgba(0,195,235,0.35)" }}
            >
              <Zap size={16} />
              Schedule a Live Demo
              <ArrowRight size={16} />
            </a>
            <a
              href="tel:+918855891936"
              className="flex items-center gap-2.5 h-14 px-8 rounded-full font-bold text-sm"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.7)" }}
            >
              Call Our Team
            </a>
          </motion.div>

          <div className="flex flex-wrap items-center justify-center gap-7 text-xs font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.2)" }}>
            {["No setup fee", "48hr onboarding", "MeitY Recognised", "100% encrypted"].map(t => (
              <span key={t} className="flex items-center gap-2">
                <span className="w-1 h-1 rounded-full bg-cyan-500" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// ── Main Page ─────────────────────────────────────────────────────────────────
const HomePage = () => {
  return (
    <PageTransition>
      <SEOHead
        title="CopMap — Police Field Operations Platform India"
        description="CopMap is India's leading police bandobast and patrolling platform. Digitize field operations with smart planning and real-time tracking."
        keywords="bandobast app, police patrolling platform, law enforcement digitization, officer tracking software India, smart policing app"
        canonical="/"
      />
      <FAQSchema />
      <main className="min-h-screen overflow-x-hidden relative font-sans" style={{ background: "#030712", color: "white" }}>

        <div className="absolute top-0 w-full z-50">
          <Navbar />
        </div>

        {/* HERO */}
        <GlassHero />

        {/* TICKER */}
        <div className="relative z-20 border-t border-b border-cyan-500/10" style={{ background: "#03111e" }}>
          <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(0,195,235,0.35), transparent)" }} />
          <div className="flex items-center">
            <div className="hidden sm:flex items-center gap-2 pl-6 pr-5 py-4 border-r border-cyan-500/10 shrink-0">
              <span className="flex h-1.5 w-1.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-60" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-cyan-400" />
              </span>
              <span className="text-[9px] font-black uppercase tracking-[0.22em]" style={{ color: "rgba(0,195,235,0.6)" }}>Live Feed</span>
            </div>
            <div className="flex-1 py-3.5 overflow-hidden">
              <MarqueeTicker items={tickerItems} speed="normal" dark={true} />
            </div>
          </div>
        </div>

        {/* HOW IT WORKS */}
        <HowItWorksSection />

        {/* 3D ECOSYSTEM */}
        <EcosystemLayers3D />

        {/* GLASS STATS */}
        <GlassStats />

        {/* GLASS FEATURES (Bento Grid) */}
        <GlassFeatures />

        {/* FAQ */}
        <FAQSection />

        {/* CTA */}
        <CTASection />

        <Footer />
      </main>
    </PageTransition>
  );
};

export default HomePage;
